// Gestion de la connexion
document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();
    document.getElementById('loginBox').style.display = 'none';
    document.getElementById('paymentBox').style.display = 'block';
});

// Gestion de la soumission des informations de paiement
document.getElementById('paymentForm').addEventListener('submit', function(event) {
    event.preventDefault();
    document.getElementById('paymentBox').style.display = 'none';
    document.getElementById('chatBox').style.display = 'block';
});

// Gestion du chat
function sendMessage() {
    const chatInput = document.getElementById('chatInput');
    const chatMessages = document.getElementById('chatMessages');
    if (chatInput.value.trim() !== '') {
        // Message du client
        const clientMessage = document.createElement('p');
        clientMessage.innerHTML = `<strong>Vous:</strong> ${chatInput.value}`;
        chatMessages.appendChild(clientMessage);

        // Réponse automatique du service client
        setTimeout(() => {
            const serviceMessage = document.createElement('p');
            serviceMessage.innerHTML = `<strong>Service Client:</strong> Nous avons bien reçu votre message. Votre paiement est en cours de traitement.`;
            chatMessages.appendChild(serviceMessage);
        }, 1000);

        chatInput.value = '';
        chatMessages.scrollTop = chatMessages.scrollHeight; // Faire défiler vers le bas
    }
}